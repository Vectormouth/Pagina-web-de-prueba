'use client'
import { useState } from 'react'

interface WaitlistFormProps {
  variant?: 'hero' | 'footer'
}

export default function WaitlistForm({ variant = 'hero' }: WaitlistFormProps) {
  const [email, setEmail] = useState('')
  const [name, setName] = useState('')
  const [status, setStatus] = useState<'idle' | 'loading' | 'success' | 'error' | 'duplicate'>('idle')
  const [message, setMessage] = useState('')

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!email) return
    setStatus('loading')

    try {
      const res = await fetch('/api/waitlist', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email, name }),
      })
      const data = await res.json()

      if (res.status === 409) {
        setStatus('duplicate')
        setMessage('Dit e-mailadres staat al op de lijst! 🎉')
      } else if (!res.ok) {
        setStatus('error')
        setMessage(data.error || 'Er ging iets mis. Probeer opnieuw.')
      } else {
        setStatus('success')
        setMessage('Gelukt! Controleer je inbox voor een bevestiging. 🌟')
      }
    } catch {
      setStatus('error')
      setMessage('Verbindingsfout. Controleer je internet.')
    }
  }

  if (status === 'success') {
    return (
      <div className={`rounded-2xl p-6 text-center ${variant === 'hero' ? 'bg-white/10 backdrop-blur border border-white/20' : 'bg-blue-50 border border-blue-100'}`}>
        <div className="text-4xl mb-3">🎉</div>
        <p className={`font-bold text-lg ${variant === 'hero' ? 'text-white' : 'text-blue-900'}`}>
          Je staat op de wachtlijst!
        </p>
        <p className={`text-sm mt-1 ${variant === 'hero' ? 'text-blue-100' : 'text-blue-600'}`}>
          {message}
        </p>
      </div>
    )
  }

  return (
    <form onSubmit={handleSubmit} className="w-full">
      <div className="flex flex-col gap-3">
        <input
          type="text"
          placeholder="Jouw naam (optioneel)"
          value={name}
          onChange={e => setName(e.target.value)}
          className={`w-full rounded-xl px-4 py-3 text-sm outline-none transition-all
            ${variant === 'hero'
              ? 'bg-white/15 border border-white/25 text-white placeholder:text-blue-200 focus:bg-white/25 focus:border-white/50'
              : 'bg-white border border-gray-200 text-gray-800 placeholder:text-gray-400 focus:border-blue-400'
            }`}
        />
        <input
          type="email"
          required
          placeholder="jouw@email.nl"
          value={email}
          onChange={e => setEmail(e.target.value)}
          className={`w-full rounded-xl px-4 py-3 text-sm outline-none transition-all
            ${variant === 'hero'
              ? 'bg-white/15 border border-white/25 text-white placeholder:text-blue-200 focus:bg-white/25 focus:border-white/50'
              : 'bg-white border border-gray-200 text-gray-800 placeholder:text-gray-400 focus:border-blue-400'
            }`}
        />
        <button
          type="submit"
          disabled={status === 'loading'}
          className={`w-full rounded-xl py-3.5 font-bold text-sm transition-all active:scale-95
            ${variant === 'hero'
              ? 'bg-yellow-400 text-yellow-900 hover:bg-yellow-300 disabled:opacity-60'
              : 'bg-blue-600 text-white hover:bg-blue-700 disabled:opacity-60'
            }`}
        >
          {status === 'loading' ? 'Bezig...' : '⭐ Reserveer mijn SmileQuest kit'}
        </button>
      </div>
      {(status === 'error' || status === 'duplicate') && (
        <p className={`text-xs mt-2 text-center ${status === 'duplicate' ? 'text-yellow-300' : 'text-red-300'}`}>
          {message}
        </p>
      )}
      <p className={`text-xs text-center mt-2 ${variant === 'hero' ? 'text-blue-200' : 'text-gray-400'}`}>
        Geen creditcard nodig · Geen spam · Je kunt altijd afmelden
      </p>
    </form>
  )
}
