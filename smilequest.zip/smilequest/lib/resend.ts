import { Resend } from 'resend'

const resend = new Resend(process.env.RESEND_API_KEY)
const FROM = process.env.RESEND_FROM_EMAIL || 'hallo@smilequest.nl'

export async function sendWelcomeEmail(email: string, name?: string) {
  const firstName = name?.split(' ')[0] || 'Hoi'

  const html = `
<!DOCTYPE html>
<html lang="nl">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Welkom bij SmileQuest!</title>
  <style>
    body { font-family: 'Helvetica Neue', Helvetica, Arial, sans-serif; background: #FFF8F0; margin: 0; padding: 0; }
    .container { max-width: 560px; margin: 40px auto; background: #ffffff; border-radius: 16px; overflow: hidden; }
    .header { background: #1B4FD8; padding: 40px 32px; text-align: center; }
    .header-star { font-size: 48px; display: block; margin-bottom: 12px; }
    .header h1 { color: #ffffff; font-size: 26px; margin: 0; font-weight: 700; letter-spacing: -0.5px; }
    .header p { color: #BFCFFF; font-size: 14px; margin: 8px 0 0; }
    .body { padding: 36px 32px; }
    .body h2 { color: #0F172A; font-size: 20px; margin: 0 0 12px; }
    .body p { color: #475569; font-size: 15px; line-height: 1.7; margin: 0 0 16px; }
    .highlight { background: #EEF2FF; border-radius: 12px; padding: 20px 24px; margin: 24px 0; }
    .highlight p { margin: 0; color: #3730A3; font-size: 14px; font-weight: 600; }
    .steps { margin: 24px 0; }
    .step { display: flex; gap: 12px; margin-bottom: 16px; align-items: flex-start; }
    .step-num { background: #DBEAFE; color: #1D4ED8; border-radius: 50%; width: 28px; height: 28px; display: flex; align-items: center; justify-content: center; font-weight: 700; font-size: 13px; flex-shrink: 0; padding: 6px; }
    .step p { margin: 0; color: #374151; font-size: 14px; line-height: 1.6; }
    .cta { text-align: center; margin: 32px 0; }
    .cta a { background: #1B4FD8; color: #ffffff; padding: 14px 32px; border-radius: 10px; text-decoration: none; font-weight: 700; font-size: 15px; display: inline-block; }
    .footer { padding: 24px 32px; border-top: 1px solid #F1F5F9; text-align: center; }
    .footer p { color: #94A3B8; font-size: 12px; margin: 0; }
  </style>
</head>
<body>
  <div class="container">
    <div class="header">
      <span class="header-star">🌟</span>
      <h1>Welkom bij SmileQuest!</h1>
      <p>Je staat op de wachtlijst voor de eerste editie</p>
    </div>
    <div class="body">
      <h2>Hoi ${firstName}! Fijn dat je erbij bent.</h2>
      <p>
        Je staat nu op de wachtlijst voor <strong>SmileQuest</strong> — het 24-dagen avontuurkit dat tandpoetsen verandert in het favoriete moment van de dag voor jouw kind.
      </p>

      <div class="highlight">
        <p>🎯 Wij maken slechts 500 kits voor de eerste editie. Als early adopter heb je prioriteit én ontvang je de introductieprijs van €29 (i.p.v. €34).</p>
      </div>

      <p>Wat kun je verwachten?</p>

      <div class="steps">
        <div class="step">
          <div class="step-num">1</div>
          <p><strong>Nu</strong> — Wij sturen je updates terwijl we de kits produceren. Jij krijgt als eerste te zien wat erin zit.</p>
        </div>
        <div class="step">
          <div class="step-num">2</div>
          <p><strong>Pre-order</strong> — Wanneer de kits klaar zijn, ontvang je als eerste de link om te bestellen tegen early access prijs.</p>
        </div>
        <div class="step">
          <div class="step-num">3</div>
          <p><strong>Levering</strong> — Je SmileQuest kit arriveert thuis. De avonturen kunnen beginnen!</p>
        </div>
      </div>

      <p>Heb je vragen? Stuur gewoon een reply op deze e-mail. We lezen alles.</p>

      <div class="cta">
        <a href="https://smilequest.nl">Bekijk de landing page</a>
      </div>
    </div>
    <div class="footer">
      <p>SmileQuest · Nederland · Je ontvangt dit omdat je je hebt aangemeld op smilequest.nl</p>
      <p style="margin-top: 8px;"><a href="#" style="color: #94A3B8;">Afmelden</a></p>
    </div>
  </div>
</body>
</html>
  `

  try {
    const { data, error } = await resend.emails.send({
      from: FROM,
      to: email,
      subject: '🌟 Welkom bij SmileQuest — je plek is gereserveerd!',
      html,
    })
    if (error) console.error('Resend error:', error)
    return { success: !error, data }
  } catch (err) {
    console.error('Email send failed:', err)
    return { success: false }
  }
}
