import type { Metadata } from 'next'
import WaitlistForm from '@/components/WaitlistForm'

export const metadata: Metadata = {
  title: 'SmileQuest — Tandpoetsen zonder strijd in 24 dagen',
  description: 'Het gamified avontuurkit dat tandpoetsen verandert in het favoriete moment van de dag. Voor kinderen van 3 tot 10 jaar.',
  openGraph: {
    title: 'SmileQuest — Tandpoetsen zonder strijd',
    description: 'Het 24-dagen avontuurkit voor kinderen. Geen ruzie meer. Alleen plezier.',
  },
}

export default function Home() {
  return (
    <main className="min-h-screen bg-[#FAFBFF]" style={{ fontFamily: "'Plus Jakarta Sans', 'Inter', system-ui, sans-serif" }}>

      {/* Google Font */}
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap');
        * { box-sizing: border-box; }
        html { scroll-behavior: smooth; }

        @keyframes float {
          0%, 100% { transform: translateY(0px) rotate(-2deg); }
          50% { transform: translateY(-8px) rotate(2deg); }
        }
        @keyframes floatSlow {
          0%, 100% { transform: translateY(0px); }
          50% { transform: translateY(-12px); }
        }
        @keyframes fadeUp {
          from { opacity: 0; transform: translateY(20px); }
          to { opacity: 1; transform: translateY(0); }
        }
        @keyframes pulse-dot {
          0%, 100% { opacity: 1; }
          50% { opacity: 0.4; }
        }
        .float { animation: float 4s ease-in-out infinite; }
        .float-slow { animation: floatSlow 6s ease-in-out infinite; }
        .fade-up { animation: fadeUp 0.6s ease forwards; }
        .pulse-dot { animation: pulse-dot 2s ease-in-out infinite; }

        .day-box {
          aspect-ratio: 1;
          border-radius: 10px;
          display: flex;
          align-items: center;
          justify-content: center;
          font-weight: 800;
          font-size: 16px;
          color: white;
          position: relative;
          transition: transform 0.2s;
        }
        .day-box:hover { transform: scale(1.08); }
        .day-open { opacity: 0.4; }

        .card-hover {
          transition: transform 0.2s, box-shadow 0.2s;
        }
        .card-hover:hover {
          transform: translateY(-3px);
        }
      `}</style>

      {/* NAV */}
      <nav className="max-w-5xl mx-auto px-6 py-5 flex justify-between items-center">
        <div className="flex items-center gap-2">
          <span className="text-2xl font-extrabold tracking-tight text-blue-700">
            Smile<span className="text-yellow-400">Quest</span>
          </span>
          <span className="text-xs bg-blue-100 text-blue-700 px-2 py-0.5 rounded-full font-semibold">BÈTA</span>
        </div>
        <a
          href="#wachtlijst"
          className="bg-blue-600 text-white text-sm font-bold px-5 py-2.5 rounded-xl hover:bg-blue-700 transition-colors"
        >
          Reserveer kit →
        </a>
      </nav>

      {/* HERO */}
      <section className="relative overflow-hidden bg-gradient-to-br from-blue-600 via-blue-700 to-indigo-800 text-white">
        {/* Decoratieve cirkels */}
        <div className="absolute top-0 right-0 w-96 h-96 bg-yellow-400/10 rounded-full blur-3xl -translate-y-1/2 translate-x-1/3" />
        <div className="absolute bottom-0 left-0 w-64 h-64 bg-blue-300/10 rounded-full blur-2xl translate-y-1/2 -translate-x-1/4" />

        <div className="max-w-5xl mx-auto px-6 py-20 grid lg:grid-cols-2 gap-12 items-center relative z-10">
          <div className="fade-up">
            <div className="inline-flex items-center gap-2 bg-white/15 rounded-full px-4 py-2 text-sm font-semibold mb-6 border border-white/20">
              <span className="w-2 h-2 bg-yellow-400 rounded-full pulse-dot" />
              247 gezinnen op de wachtlijst
            </div>

            <h1 className="text-4xl lg:text-5xl font-extrabold leading-tight mb-5 tracking-tight">
              Geen ruzie meer
              <br />
              over tandpoetsen.
              <br />
              <span className="text-yellow-300">Nooit meer.</span>
            </h1>

            <p className="text-blue-100 text-lg leading-relaxed mb-8 max-w-md">
              SmileQuest is het 24-dagen avontuurkit dat tandpoetsen verandert in het favoriete moment van de dag voor jouw kind.
            </p>

            <WaitlistForm variant="hero" />
          </div>

          {/* Product preview */}
          <div className="flex justify-center lg:justify-end">
            <div className="relative">
              {/* Kalender preview */}
              <div className="float-slow bg-white rounded-3xl p-5 shadow-2xl w-80">
                <div className="flex justify-between items-center mb-4">
                  <div>
                    <p className="font-extrabold text-gray-900 text-lg">Smile Adventure</p>
                    <p className="text-xs text-gray-400">24-dagen missie kalender</p>
                  </div>
                  <span className="text-3xl">🏆</span>
                </div>
                {/* Kalender grid */}
                <div className="grid grid-cols-6 gap-1.5 mb-3">
                  {Array.from({length: 24}, (_, i) => {
                    const colors = ['#3B82F6','#8B5CF6','#10B981','#F59E0B','#EF4444','#EC4899','#06B6D4','#84CC16']
                    const col = colors[i % colors.length]
                    const isOpen = i < 7
                    const isToday = i === 6
                    return (
                      <div
                        key={i}
                        className={`day-box ${!isOpen ? 'day-open' : ''}`}
                        style={{
                          background: col,
                          boxShadow: isToday ? `0 0 0 3px white, 0 0 0 5px ${col}` : undefined,
                          fontSize: '14px',
                        }}
                      >
                        {isToday ? '⭐' : isOpen ? '✓' : i + 1}
                      </div>
                    )
                  })}
                </div>
                <div className="bg-blue-50 rounded-xl p-3 flex items-center gap-3">
                  <span className="text-2xl">🎁</span>
                  <div>
                    <p className="text-xs font-bold text-blue-900">Dag 7 beloond!</p>
                    <p className="text-xs text-blue-600">Geheime sticker ontgrendeld</p>
                  </div>
                </div>
              </div>

              {/* Floating badges */}
              <div className="float absolute -top-4 -left-6 bg-yellow-400 text-yellow-900 text-xs font-bold px-3 py-2 rounded-2xl shadow-lg">
                🌟 Held van de dag!
              </div>
              <div className="float absolute -bottom-4 -right-4 bg-green-500 text-white text-xs font-bold px-3 py-2 rounded-2xl shadow-lg" style={{animationDelay: '1s'}}>
                ✓ Missie voltooid
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* PROBLEEM */}
      <section className="max-w-4xl mx-auto px-6 py-20">
        <div className="text-center mb-12">
          <p className="text-xs font-bold tracking-widest text-blue-500 uppercase mb-3">Het probleem</p>
          <h2 className="text-3xl lg:text-4xl font-extrabold text-gray-900 leading-tight">
            Ken jij dit gevoel?
          </h2>
        </div>

        <div className="grid md:grid-cols-3 gap-5">
          {[
            {
              emoji: '😤',
              title: '4x vragen voor 1x poetsen',
              body: 'Het is 21:00. Je hebt het al drie keer gezegd. Je kind doet alsof ze je niet hoort. Elke. Avond. Weer.'
            },
            {
              emoji: '😩',
              title: 'Je bent op aan het einde van de dag',
              body: 'Je wilt niet schreeuwen. Niet onderhandelen. Maar het lukt gewoon niet zonder strijd.'
            },
            {
              emoji: '🤷',
              title: 'Apps en stickers werken 3 dagen',
              body: 'Je hebt van alles geprobeerd. Na een week is de nieuwigheid eraf en begint het weer van voor af aan.'
            },
          ].map((item) => (
            <div key={item.title} className="card-hover bg-white rounded-2xl p-6 border border-gray-100 shadow-sm">
              <span className="text-4xl block mb-4">{item.emoji}</span>
              <h3 className="font-bold text-gray-900 mb-2">{item.title}</h3>
              <p className="text-gray-500 text-sm leading-relaxed">{item.body}</p>
            </div>
          ))}
        </div>

        <div className="mt-8 bg-blue-600 rounded-2xl p-6 text-white text-center max-w-2xl mx-auto">
          <p className="text-lg font-bold">
            Tandpoetsen is geen hygiëneprobleem.
            Het is een <span className="text-yellow-300">motivatieprobleem.</span>
          </p>
          <p className="text-blue-200 text-sm mt-2">
            En kinderen worden alleen gemotiveerd door één ding: spelen.
          </p>
        </div>
      </section>

      {/* OPLOSSING */}
      <section className="bg-gradient-to-b from-blue-50 to-white py-20">
        <div className="max-w-4xl mx-auto px-6">
          <div className="text-center mb-12">
            <p className="text-xs font-bold tracking-widest text-blue-500 uppercase mb-3">De oplossing</p>
            <h2 className="text-3xl lg:text-4xl font-extrabold text-gray-900 leading-tight mb-4">
              SmileQuest: de 24-dagen missie
            </h2>
            <p className="text-gray-500 max-w-xl mx-auto text-lg">
              Geen app. Geen cadeautjes als omkoping. Een compleet fysiek systeem dat het gewoontepatroon van je kind herprogrammeert.
            </p>
          </div>

          {/* Kit inhoud */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-12">
            {[
              { icon: '🗺️', label: 'Avontuurkalender', sub: '24 dagen uitgestippeld' },
              { icon: '⭐', label: 'Beloningsstickers', sub: 'Elke dag een verrassing' },
              { icon: '📖', label: 'Heldenboekje', sub: 'Jouw kind is de held' },
              { icon: '🏆', label: 'Prijsceremonie', sub: 'Dag 24 is speciaal' },
            ].map((item) => (
              <div key={item.label} className="card-hover bg-white rounded-2xl p-5 text-center border border-gray-100 shadow-sm">
                <span className="text-3xl block mb-3">{item.icon}</span>
                <p className="font-bold text-gray-900 text-sm">{item.label}</p>
                <p className="text-gray-400 text-xs mt-1">{item.sub}</p>
              </div>
            ))}
          </div>

          {/* Hoe het werkt */}
          <div className="bg-white rounded-3xl p-8 border border-gray-100 shadow-sm">
            <h3 className="font-extrabold text-gray-900 text-xl mb-6 text-center">Zo werkt het</h3>
            <div className="space-y-5">
              {[
                { num: '1', title: 'Je kind kiest zijn missie', body: 'Ruimtereiziger, junglewachter of tijddetective — jouw kind beslist wie het wil zijn. Dat gevoel van eigenaarschap verandert alles.' },
                { num: '2', title: 'Elke dag: poetsen = beloning', body: "Goed geborsteld? Klap de dagdoos open. Een sticker, een aanwijzing of een mini-verrassing. De volgende dag kan niet snel genoeg komen." },
                { num: '3', title: 'Dag 24: het grote feest', body: 'Heldencertificaat, eindprijs en — het belangrijkste — een gewoonte die voor altijd blijft. Geen gedoe meer.' },
              ].map((step) => (
                <div key={step.num} className="flex gap-4 items-start">
                  <div className="w-10 h-10 rounded-full bg-blue-100 flex items-center justify-center font-extrabold text-blue-700 flex-shrink-0 text-sm">
                    {step.num}
                  </div>
                  <div>
                    <p className="font-bold text-gray-900 mb-1">{step.title}</p>
                    <p className="text-gray-500 text-sm leading-relaxed">{step.body}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* EMOTIONELE VOORDELEN */}
      <section className="max-w-4xl mx-auto px-6 py-20">
        <div className="text-center mb-12">
          <p className="text-xs font-bold tracking-widest text-blue-500 uppercase mb-3">Wat je écht krijgt</p>
          <h2 className="text-3xl font-extrabold text-gray-900">
            Meer dan een routine
          </h2>
        </div>
        <div className="grid md:grid-cols-2 gap-5">
          {[
            { icon: '🌙', title: 'Avonden zonder conflict', body: 'Jij bent niet meer de politie. Je kind gehoorzaamt het spel, niet jou. Dat is een heel ander gezinsdynamiek.' },
            { icon: '💪', title: 'Echt zelfvertrouwen bij je kind', body: '"Ik heb mijn missie voltooid." Dat zegt een kind dat zich capabel voelt. Dat is groter dan tandpoetsen.' },
            { icon: '💛', title: 'Een moment dat van jullie is', body: 'Het dagelijkse doosje openen samen. Klein, maar speciaal. Kinderen onthouden die dingen voor altijd.' },
            { icon: '🧠', title: 'Een gewoonte die blijft', body: '24 dagen is precies genoeg voor het kinderbrein om een routine als "normaal" te registreren. Wetenschap, geen magie.' },
          ].map((item) => (
            <div key={item.title} className="card-hover bg-white rounded-2xl p-6 border border-gray-100 shadow-sm flex gap-4">
              <span className="text-3xl flex-shrink-0">{item.icon}</span>
              <div>
                <p className="font-bold text-gray-900 mb-1">{item.title}</p>
                <p className="text-gray-500 text-sm leading-relaxed">{item.body}</p>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* SOCIAL PROOF */}
      <section className="bg-blue-50 py-20">
        <div className="max-w-4xl mx-auto px-6">
          <div className="text-center mb-10">
            <p className="text-xs font-bold tracking-widest text-blue-500 uppercase mb-3">Ouders over het prototype</p>
            <h2 className="text-3xl font-extrabold text-gray-900">Wat families zeggen</h2>
          </div>
          <div className="grid md:grid-cols-3 gap-5">
            {[
              { name: 'Sara M.', child: 'Mama van Lucas, 5 jaar · Utrecht', stars: 5, quote: 'Voor het eerst in 3 jaar liep mijn zoon zelf naar de badkamer om te poetsen. Ik moest bijna huilen.' },
              { name: 'Javier R.', child: 'Papa van Sofía, 7 jaar · Amsterdam', stars: 5, quote: 'Wat me het meest verraste: zijn zelfvertrouwen groeide ook. Hij zegt trots "ik heb mijn missie gedaan".' },
              { name: 'Elena K.', child: 'Mama van Mateo, 4 jaar · Rotterdam', stars: 5, quote: 'Ik dacht dat het 3 dagen zou werken. 6 weken later vraagt hij er nog steeds zelf om. Ik kan het niet geloven.' },
            ].map((r) => (
              <div key={r.name} className="card-hover bg-white rounded-2xl p-6 border border-gray-100 shadow-sm">
                <div className="flex gap-0.5 mb-3">
                  {Array.from({length: r.stars}).map((_, i) => (
                    <span key={i} className="text-yellow-400 text-sm">★</span>
                  ))}
                </div>
                <p className="text-gray-700 text-sm leading-relaxed mb-4 italic">"{r.quote}"</p>
                <div>
                  <p className="font-bold text-gray-900 text-sm">{r.name}</p>
                  <p className="text-gray-400 text-xs">{r.child}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* PRIJS + CTA */}
      <section id="wachtlijst" className="bg-gradient-to-br from-blue-600 via-blue-700 to-indigo-800 text-white py-20">
        <div className="max-w-2xl mx-auto px-6 text-center">
          <div className="inline-flex items-center gap-2 bg-white/15 rounded-full px-4 py-2 text-sm font-semibold mb-6 border border-white/20">
            <span className="w-2 h-2 bg-yellow-400 rounded-full pulse-dot" />
            Wachtlijst open — slechts 500 kits beschikbaar
          </div>
          <h2 className="text-3xl lg:text-4xl font-extrabold mb-4">
            Zet je kind op weg
            <br />
            naar <span className="text-yellow-300">avontuur.</span>
          </h2>
          <p className="text-blue-100 text-lg mb-6 max-w-md mx-auto">
            Early adopters ontvangen de introductieprijs en zijn als eerste aan de beurt bij het eerste verzending.
          </p>
          <div className="flex items-baseline gap-3 justify-center mb-8">
            <span className="text-blue-300 line-through text-lg">€34</span>
            <span className="text-5xl font-extrabold">€29</span>
            <span className="text-blue-200 text-sm">early access prijs</span>
          </div>
          <div className="max-w-sm mx-auto">
            <WaitlistForm variant="hero" />
          </div>
        </div>
      </section>

      {/* FAQ */}
      <section className="max-w-2xl mx-auto px-6 py-20">
        <h2 className="text-2xl font-extrabold text-gray-900 mb-8 text-center">Veelgestelde vragen</h2>
        <div className="space-y-0">
          {[
            { q: 'Voor welke leeftijd is het geschikt?', a: 'Van 3 tot 10 jaar. We hebben twee varianten: een visuele voor de kleintjes en een tekst-/avonturenversie voor de grotere kinderen.' },
            { q: 'Wat gebeurt er na 24 dagen?', a: "De gewoonte is dan al geïnstalleerd. We lanceren ook uitbreidingspakketten voor wie de avonturen wil voortzetten." },
            { q: 'Wanneer wordt geleverd?', a: 'Wij zijn in productie. Early adopters ontvangen de kits bij het eerste verzending. Je krijgt een email met een exacte datum.' },
            { q: 'Wat als het niet werkt bij mijn kind?', a: 'Volledige terugbetaalgarantie binnen 14 dagen. Geen vragen, geen gedoe.' },
            { q: 'Is dit een abonnement?', a: 'Nee. Eenmalige aankoop. Geen verborgen kosten, geen automatische verlengingen.' },
          ].map((faq, i) => (
            <div key={i} className="border-t border-gray-100 py-5">
              <p className="font-bold text-gray-900 mb-2 text-sm">{faq.q}</p>
              <p className="text-gray-500 text-sm leading-relaxed">{faq.a}</p>
            </div>
          ))}
          <div className="border-t border-gray-100" />
        </div>
      </section>

      {/* FOOTER */}
      <footer className="border-t border-gray-100 py-10">
        <div className="max-w-4xl mx-auto px-6 flex flex-col md:flex-row justify-between items-center gap-4">
          <span className="text-xl font-extrabold text-blue-700">
            Smile<span className="text-yellow-400">Quest</span>
          </span>
          <p className="text-gray-400 text-sm">
            © 2025 SmileQuest · Gemaakt voor gezinnen in Nederland
          </p>
          <div className="flex gap-4 text-xs text-gray-400">
            <a href="#" className="hover:text-gray-600">Privacy</a>
            <a href="#" className="hover:text-gray-600">Contact</a>
            <a href="/dashboard" className="hover:text-gray-600">Dashboard</a>
          </div>
        </div>
      </footer>
    </main>
  )
}
