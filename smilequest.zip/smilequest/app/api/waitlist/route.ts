import { NextRequest, NextResponse } from 'next/server'
import { supabaseAdmin } from '@/lib/supabase'
import { sendWelcomeEmail } from '@/lib/resend'

export async function POST(req: NextRequest) {
  try {
    const body = await req.json()
    const { email, name, childrenAges } = body

    if (!email || !email.includes('@')) {
      return NextResponse.json(
        { error: 'Ongeldig e-mailadres' },
        { status: 400 }
      )
    }

    const ip = req.headers.get('x-forwarded-for') || req.headers.get('x-real-ip') || 'unknown'
    const userAgent = req.headers.get('user-agent') || 'unknown'

    // Opslaan in Supabase
    const { data, error } = await supabaseAdmin
      .from('waitlist')
      .insert([{
        email: email.toLowerCase().trim(),
        name: name?.trim() || null,
        children_ages: childrenAges || null,
        ip_address: ip,
        user_agent: userAgent,
        source: 'landing',
      }])
      .select()

    if (error) {
      // Duplicate email
      if (error.code === '23505') {
        return NextResponse.json(
          { error: 'Dit e-mailadres staat al op de wachtlijst!', alreadyExists: true },
          { status: 409 }
        )
      }
      console.error('Supabase insert error:', error)
      return NextResponse.json(
        { error: 'Er ging iets mis. Probeer het opnieuw.' },
        { status: 500 }
      )
    }

    // Welkomstmail sturen (niet-blocking)
    sendWelcomeEmail(email, name).catch(console.error)

    return NextResponse.json(
      { success: true, message: 'Gelukt! Je staat op de wachtlijst.' },
      { status: 201 }
    )
  } catch (err) {
    console.error('Waitlist API error:', err)
    return NextResponse.json(
      { error: 'Serverfout. Probeer het opnieuw.' },
      { status: 500 }
    )
  }
}

// Leads ophalen voor dashboard (beveiligd met header)
export async function GET(req: NextRequest) {
  const auth = req.headers.get('x-dashboard-key')
  if (auth !== process.env.DASHBOARD_PASSWORD) {
    return NextResponse.json({ error: 'Niet geautoriseerd' }, { status: 401 })
  }

  const { data: leads } = await supabaseAdmin
    .from('waitlist')
    .select('id, email, name, children_ages, source, confirmed, created_at')
    .order('created_at', { ascending: false })
    .limit(500)

  const { data: stats } = await supabaseAdmin
    .from('waitlist_stats')
    .select('*')
    .single()

  const { data: daily } = await supabaseAdmin
    .from('daily_signups')
    .select('*')

  return NextResponse.json({ leads, stats, daily })
}
