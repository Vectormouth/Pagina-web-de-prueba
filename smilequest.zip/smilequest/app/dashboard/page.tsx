'use client'
import { useState, useEffect } from 'react'

interface Lead {
  id: string
  email: string
  name: string | null
  children_ages: string | null
  source: string
  confirmed: boolean
  created_at: string
}

interface Stats {
  total_leads: number
  leads_this_week: number
  leads_today: number
  confirmed_leads: number
  first_signup: string
  latest_signup: string
}

interface DailySignup {
  day: string
  signups: number
}

export default function Dashboard() {
  const [password, setPassword] = useState('')
  const [authed, setAuthed] = useState(false)
  const [authError, setAuthError] = useState(false)
  const [leads, setLeads] = useState<Lead[]>([])
  const [stats, setStats] = useState<Stats | null>(null)
  const [daily, setDaily] = useState<DailySignup[]>([])
  const [loading, setLoading] = useState(false)
  const [search, setSearch] = useState('')

  const fetchData = async (pw: string) => {
    setLoading(true)
    try {
      const res = await fetch('/api/waitlist', {
        headers: { 'x-dashboard-key': pw }
      })
      if (res.status === 401) {
        setAuthError(true)
        setLoading(false)
        return
      }
      const data = await res.json()
      setLeads(data.leads || [])
      setStats(data.stats)
      setDaily(data.daily || [])
      setAuthed(true)
    } catch {
      setAuthError(true)
    }
    setLoading(false)
  }

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault()
    fetchData(password)
  }

  const exportCSV = () => {
    const header = 'email,naam,leeftijden_kinderen,aangemeld_op\n'
    const rows = leads.map(l =>
      `${l.email},${l.name || ''},${l.children_ages || ''},${new Date(l.created_at).toLocaleString('nl-NL')}`
    ).join('\n')
    const blob = new Blob([header + rows], { type: 'text/csv' })
    const url = URL.createObjectURL(blob)
    const a = document.createElement('a')
    a.href = url
    a.download = `smilequest-leads-${new Date().toISOString().slice(0, 10)}.csv`
    a.click()
  }

  const filtered = leads.filter(l =>
    l.email.toLowerCase().includes(search.toLowerCase()) ||
    (l.name || '').toLowerCase().includes(search.toLowerCase())
  )

  const maxSignups = Math.max(...daily.map(d => d.signups), 1)

  if (!authed) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50" style={{ fontFamily: "'Plus Jakarta Sans', system-ui, sans-serif" }}>
        <style>{`@import url('https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap');`}</style>
        <div className="bg-white rounded-2xl border border-gray-100 shadow-sm p-10 w-full max-w-sm">
          <div className="text-center mb-8">
            <span className="text-3xl font-extrabold text-blue-700">Smile<span className="text-yellow-400">Quest</span></span>
            <p className="text-gray-400 text-sm mt-2">Leads Dashboard</p>
          </div>
          <form onSubmit={handleLogin} className="space-y-4">
            <input
              type="password"
              placeholder="Wachtwoord"
              value={password}
              onChange={e => { setPassword(e.target.value); setAuthError(false) }}
              className={`w-full border rounded-xl px-4 py-3 text-sm outline-none focus:border-blue-400 ${authError ? 'border-red-300 bg-red-50' : 'border-gray-200'}`}
            />
            {authError && <p className="text-xs text-red-500">Verkeerd wachtwoord</p>}
            <button
              type="submit"
              disabled={loading}
              className="w-full bg-blue-600 text-white rounded-xl py-3 font-bold text-sm hover:bg-blue-700 disabled:opacity-50 transition-colors"
            >
              {loading ? 'Laden...' : 'Inloggen'}
            </button>
          </form>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gray-50" style={{ fontFamily: "'Plus Jakarta Sans', system-ui, sans-serif" }}>
      <style>{`@import url('https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap');`}</style>

      {/* Header */}
      <div className="bg-white border-b border-gray-100">
        <div className="max-w-6xl mx-auto px-6 py-4 flex justify-between items-center">
          <span className="text-xl font-extrabold text-blue-700">Smile<span className="text-yellow-400">Quest</span> <span className="font-normal text-gray-400 text-sm">/ Dashboard</span></span>
          <div className="flex gap-3">
            <button
              onClick={exportCSV}
              className="text-sm border border-gray-200 rounded-xl px-4 py-2 hover:bg-gray-50 text-gray-600 font-medium transition-colors"
            >
              ↓ Exporteer CSV
            </button>
            <button
              onClick={() => fetchData(password)}
              className="text-sm bg-blue-600 text-white rounded-xl px-4 py-2 hover:bg-blue-700 font-medium transition-colors"
            >
              ↻ Vernieuwen
            </button>
          </div>
        </div>
      </div>

      <div className="max-w-6xl mx-auto px-6 py-8">

        {/* Stats */}
        {stats && (
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
            {[
              { label: 'Totaal leads', value: stats.total_leads, color: 'blue' },
              { label: 'Vandaag', value: stats.leads_today, color: 'green' },
              { label: 'Deze week', value: stats.leads_this_week, color: 'purple' },
              { label: 'Bevestigd', value: stats.confirmed_leads, color: 'yellow' },
            ].map((s) => (
              <div key={s.label} className="bg-white rounded-2xl border border-gray-100 p-5">
                <p className="text-xs text-gray-400 font-medium mb-1">{s.label}</p>
                <p className="text-3xl font-extrabold text-gray-900">{s.value}</p>
              </div>
            ))}
          </div>
        )}

        {/* Grafiek */}
        {daily.length > 0 && (
          <div className="bg-white rounded-2xl border border-gray-100 p-6 mb-6">
            <p className="font-bold text-gray-900 mb-6 text-sm">Aanmeldingen per dag (laatste 30 dagen)</p>
            <div className="flex items-end gap-1 h-32">
              {[...daily].reverse().map((d) => (
                <div key={d.day} className="flex-1 flex flex-col items-center gap-1 group">
                  <div
                    className="w-full bg-blue-500 rounded-t transition-all group-hover:bg-blue-400"
                    style={{ height: `${Math.max((d.signups / maxSignups) * 100, 4)}%` }}
                    title={`${d.day}: ${d.signups} aanmeldingen`}
                  />
                </div>
              ))}
            </div>
            <div className="flex justify-between mt-2 text-xs text-gray-400">
              <span>30 dagen geleden</span>
              <span>Vandaag</span>
            </div>
          </div>
        )}

        {/* Leads tabel */}
        <div className="bg-white rounded-2xl border border-gray-100">
          <div className="p-5 border-b border-gray-50 flex justify-between items-center">
            <p className="font-bold text-gray-900 text-sm">Alle leads ({filtered.length})</p>
            <input
              type="text"
              placeholder="Zoeken op email of naam..."
              value={search}
              onChange={e => setSearch(e.target.value)}
              className="border border-gray-200 rounded-xl px-3 py-2 text-sm outline-none focus:border-blue-400 w-60"
            />
          </div>
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-gray-50">
                  <th className="text-left px-5 py-3 text-xs text-gray-400 font-medium">E-mail</th>
                  <th className="text-left px-5 py-3 text-xs text-gray-400 font-medium">Naam</th>
                  <th className="text-left px-5 py-3 text-xs text-gray-400 font-medium">Bron</th>
                  <th className="text-left px-5 py-3 text-xs text-gray-400 font-medium">Status</th>
                  <th className="text-left px-5 py-3 text-xs text-gray-400 font-medium">Aangemeld</th>
                </tr>
              </thead>
              <tbody>
                {filtered.map((lead) => (
                  <tr key={lead.id} className="border-b border-gray-50 hover:bg-gray-50/50 transition-colors">
                    <td className="px-5 py-3 text-gray-900 font-medium">{lead.email}</td>
                    <td className="px-5 py-3 text-gray-500">{lead.name || <span className="text-gray-300">—</span>}</td>
                    <td className="px-5 py-3">
                      <span className="text-xs bg-blue-50 text-blue-600 px-2 py-0.5 rounded-full font-medium">{lead.source}</span>
                    </td>
                    <td className="px-5 py-3">
                      {lead.confirmed
                        ? <span className="text-xs bg-green-50 text-green-600 px-2 py-0.5 rounded-full font-medium">Bevestigd</span>
                        : <span className="text-xs bg-gray-50 text-gray-400 px-2 py-0.5 rounded-full font-medium">Wachtend</span>
                      }
                    </td>
                    <td className="px-5 py-3 text-gray-400 text-xs">
                      {new Date(lead.created_at).toLocaleString('nl-NL', { day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' })}
                    </td>
                  </tr>
                ))}
                {filtered.length === 0 && (
                  <tr>
                    <td colSpan={5} className="text-center py-12 text-gray-400 text-sm">
                      Geen leads gevonden
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  )
}
