-- SmileQuest Waitlist Schema
-- Plak dit in de Supabase SQL Editor en klik Run

CREATE TABLE IF NOT EXISTS waitlist (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  email TEXT NOT NULL UNIQUE,
  name TEXT,
  children_ages TEXT,
  source TEXT DEFAULT 'landing',
  ip_address TEXT,
  user_agent TEXT,
  confirmed BOOLEAN DEFAULT FALSE,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Index voor snelle lookups
CREATE INDEX IF NOT EXISTS waitlist_email_idx ON waitlist(email);
CREATE INDEX IF NOT EXISTS waitlist_created_at_idx ON waitlist(created_at DESC);

-- Row Level Security: alleen service_role kan lezen/schrijven
ALTER TABLE waitlist ENABLE ROW LEVEL SECURITY;

-- Publiek mag ALLEEN inserten (voor de form submit)
CREATE POLICY "Public can insert" ON waitlist
  FOR INSERT WITH CHECK (true);

-- Alleen service_role (server-side) mag alles lezen
CREATE POLICY "Service role can read all" ON waitlist
  FOR SELECT USING (auth.role() = 'service_role');

-- Stats view voor het dashboard
CREATE OR REPLACE VIEW waitlist_stats AS
SELECT
  COUNT(*) AS total_leads,
  COUNT(*) FILTER (WHERE created_at >= NOW() - INTERVAL '7 days') AS leads_this_week,
  COUNT(*) FILTER (WHERE created_at >= NOW() - INTERVAL '24 hours') AS leads_today,
  COUNT(*) FILTER (WHERE confirmed = true) AS confirmed_leads,
  MIN(created_at) AS first_signup,
  MAX(created_at) AS latest_signup
FROM waitlist;

-- Dagelijkse signups voor de grafiek (laatste 30 dagen)
CREATE OR REPLACE VIEW daily_signups AS
SELECT
  DATE(created_at) AS day,
  COUNT(*) AS signups
FROM waitlist
WHERE created_at >= NOW() - INTERVAL '30 days'
GROUP BY DATE(created_at)
ORDER BY day DESC;
